/*

  This program provides cartesian type graph function

  Revisions
  rev     date        author      description
  1       12-24-2015  kasprzak    initial creation

  Updated by Bodmer to be an example for the library here:
  https://github.com/Bodmer/TFT_eSPI
  
*/

// Size of sprite image for the scrolling text, this requires ~14 Kbytes of RAM
#define IWIDTH  320
#define IHEIGHT 30

// Pause in milliseconds to set scroll speed
#define WAIT 0
#include <Arduino.h>
#include <SPI.h>
#include <TFT_eSPI.h>                 // Include the graphics library (this includes the sprite functions)

TFT_eSPI    tft = TFT_eSPI();         // Create object "tft"

TFT_eSprite img = TFT_eSprite(&tft);  // Create Sprite object "img" with pointer to "tft" object
//                                    // the pointer is used by pushSprite() to push it onto the TFT


bool update1 = true;
double ox = -99999, oy = -99999; // Force them to be off screen

#define  TFT_BL 5 
#define noSinus

float aTemperature[24];
float aHumidity2[24];  
bool First = true;

void Trace(TFT_eSPI &tft, double x,  double y,  byte Xdp, byte Ydp,
           double gx, double gy,
           double w, double h,
           double xlo, double xhi, double xinc,
           double ylo, double yhi, double yinc,
           char const *title, int LabelPos, bool &update1,
           uint16_t Fcolor, uint16_t BKcolor, uint16_t Gcolor);

void drawGraph();
void build_banner(String msg, int xpos);
void numberBox(int num, int x, int y);
void build_Rect(String msg, int xpos);
unsigned int rainbow(byte value);
void drawLineW(uint16_t x0, uint16_t y0, uint16_t w, uint16_t Fcolor, uint16_t Bcolor);
void drawLineH(uint16_t x0, uint16_t y0, uint16_t h, uint16_t Fcolor, uint16_t Bcolor);
void SetGraph(TFT_eSPI &tft,int XStart, int YStart, int XAbstand, int YAbstand,int XLines, int YLines, uint32_t Fcolor, uint32_t Bcolor, uint32_t ColorLines);

void SetGraphUnion(TFT_eSPI &tft, double x, double y, 
                           byte Xdp, byte Ydp,
                           double gx, double gy, double w, double h,
                           double xlo, double xhi, double xinc,
                           double ylo, double yhi, double yinc,
                           uint16_t Fcolor, uint16_t Bcolor, uint16_t Gcolor);

void SetGraphData(TFT_eSPI &tft, double x,  double y,  
           double gx, double gy,
           double w, double h,
           double xlo, double xhi, double xinc,
           double ylo, double yhi, double yinc,
           bool &update1, unsigned int color);
void MakeRadArray();
// -------------------------------------------------------------------------
// Setup
// -------------------------------------------------------------------------
void setup(void) {
    Serial.begin(115200);
  pinMode(TFT_BL, OUTPUT);
  tft.init();
  tft.setRotation(1);

  tft.fillScreen(TFT_PINK);
}


// -------------------------------------------------------------------------
// Main loop
// -------------------------------------------------------------------------
void loop() {
    // Create the sprite and clear background to black
    img.createSprite(IWIDTH, IHEIGHT);
    //img.fillSprite(TFT_BLACK); // Optional here as we fill the sprite later anyway

    for (int pos = IWIDTH; pos > 0; pos--)
    {
      build_Rect("Hello World", pos);
      img.pushSprite(0, 0);
   
      delay(WAIT);
    }

    // Delete sprite to free up the memory
    img.deleteSprite();
  float x;
  float y;
   MakeRadArray();

     img.createSprite(260, 190);
   
       SetGraph(img,0,2,15,15,12,16, TFT_NAVY, TFT_GOLD, TFT_LIGHTGREY);
       SetGraphUnion(img, x, y, 0, 1, 30, 172, 220, 160, 0, 24, 4, 0, 31, 5,TFT_NAVY,TFT_GOLD, TFT_RED);

update1 = true;
#ifdef Sinus 
for (x = 0; x <= 6.3; x += .1)
   {
    y = sin(x);
    y += 20;
 #else    
 for (x = 0; x <= 24 ; x++) 
 {
     int i = round(x);
     y =  aTemperature[i];
 
#endif
    
      SetGraphData(img, x, y, 30, 172, 220, 160, 0, 24, 4, 0, 31, 5,  update1, TFT_DARKGREEN);

  }
     img.pushSprite(50, 40);
        delay(WAIT);
           img.deleteSprite();

}

void MakeRadArray()
{

    for(int i = 0; i < 24; i++)
    {
       aTemperature[i] =  (random(30));
     }
}

/////////////////////////////////////////////////////////////////////////

const int hdot = 180;
const int wdot = 240;

int16_t dashline_h = 1;
int16_t dashline_w = 1;
int16_t dashline_n = hdot / dashline_h;
int16_t dashline_x = wdot / 2 - 1;
//int16_t dashline_y = dashline_h / 2;

void SetBanner()
{
  int h = IHEIGHT; 
while (h--) img.drawFastHLine(0, h, IWIDTH, rainbow(h * 4));
}


void drawLineW(TFT_eSPI &tft,uint16_t x0, uint16_t y0, uint16_t w, uint16_t Fcolor, uint16_t Bcolor)
{
for (int i = x0; i < w; i++)
if (i % 2)
tft.drawPixel(i,y0, Fcolor);
else
tft.drawPixel(i,y0, Bcolor);
}

void drawLineH(TFT_eSPI &tft, uint16_t x0, uint16_t y0, uint16_t h, uint16_t Fcolor, uint16_t Bcolor)
{
for (int i = y0; i < h; i++)
if (i % 2)
tft.drawPixel(x0, i, Fcolor);
else
tft.drawPixel(x0, i, Bcolor);
}




void build_Rect(String msg, int xpos)
{
 
SetBanner();
  // We could just use fillSprite(color) but lets be a bit more creative...

  // Fill with rainbow stripes
  

  // Draw some graphics, the text will apear to scroll over these
  img.fillRect  (IWIDTH / 2 - 20, IHEIGHT / 2 - 10, 40, 20, TFT_YELLOW);
  img.fillCircle(IWIDTH / 2, IHEIGHT / 2, 10, TFT_ORANGE);

  // Now print text on top of the graphics
  img.fillRect(xpos, 2,50,30,TFT_PURPLE);
    // Need to print twice so text appears to wrap around at left and right edges
  }



// #########################################################################
// Build the scrolling sprite image from scratch, draw text at x = xpos
// #########################################################################

void build_banner(String msg, int xpos)
{
  int h = IHEIGHT;

  // We could just use fillSprite(color) but lets be a bit more creative...

  // Fill with rainbow stripes
  while (h--) img.drawFastHLine(0, h, IWIDTH, rainbow(h * 4));

  // Draw some graphics, the text will apear to scroll over these
  img.fillRect  (IWIDTH / 2 - 20, IHEIGHT / 2 - 10, 40, 20, TFT_YELLOW);
  img.fillCircle(IWIDTH / 2, IHEIGHT / 2, 10, TFT_ORANGE);

  // Now print text on top of the graphics
  img.setTextSize(1);           // Font size scaling is x1
  img.setTextFont(4);           // Font 4 selected
  img.setTextColor(TFT_BLACK);  // Black text, no background colour
  img.setTextWrap(false);       // Turn of wrap so we can print past end of sprite

  // Need to print twice so text appears to wrap around at left and right edges
  img.setCursor(xpos, 2);  // Print text at xpos
  img.print(msg);

  img.setCursor(xpos - IWIDTH, 2); // Print text at xpos - sprite width
  img.print(msg);
}



// #########################################################################
// Return a 16 bit rainbow colour
// #########################################################################
unsigned int rainbow(byte value)
{
  // Value is expected to be in range 0-127
  // The value is converted to a spectrum colour from 0 = red through to 127 = blue

  byte red   = 0; // Red is the top 5 bits of a 16 bit colour value
  byte green = 0;// Green is the middle 6 bits
  byte blue  = 0; // Blue is the bottom 5 bits

  byte sector = value >> 5;
  byte amplit = value & 0x1F;

  switch (sector)
  {
    case 0:
      red   = 0x1F;
      green = amplit;
      blue  = 0;
      break;
    case 1:
      red   = 0x1F - amplit;
      green = 0x1F;
      blue  = 0;
      break;
    case 2:
      red   = 0;
      green = 0x1F;
      blue  = amplit;
      break;
    case 3:
      red   = 0;
      green = 0x1F - amplit;
      blue  = 0x1F;
      break;
  }

  return red << 11 | green << 6 | blue;
}




void SetGraphData(TFT_eSPI &tft, double x,  double y,  
           double gx, double gy,
           double w, double h,
           double xlo, double xhi, double xinc,
           double ylo, double yhi, double yinc,
           bool &update1, unsigned int color)
{
  double ydiv, xdiv;
  double i;
  double temp;
  int rot, newrot;
  
  // initialize old x and old y in order to draw the first point of the graph
  // but save the transformed value
  // note my transform funcition is the same as the map function, except the map uses long and we need doubles
  if (update1) {
    update1 = false;
    
    ox = (x - xlo) * ( w) / (xhi - xlo) + gx;
    oy = (y - ylo) * (gy - h - gy) / (yhi - ylo) + gy;

    if ((ox < gx) || (ox > gx+w)) {update1 = true; return;}
    if ((oy < gy-h) || (oy > gy)) {update1 = true; return;}
    }


  // the coordinates are now drawn, plot the dataSetGraphData
  // the entire plotting code are these few lines...
  // recall that ox and oy are initialized above
  x =  (x - xlo) * ( w) / (xhi - xlo) + gx;
  y =  (y - ylo) * (gy - h - gy) / (yhi - ylo) + gy;

  if ((x < gx) || (x > gx+w)) {update1 = true; return;}
  if ((y < gy-h) || (y > gy)) {update1 = true; return;}
    
    
  tft.drawLine(ox, oy, x, y, color);
  // it's up to you but drawing 2 more lines to give the graph some thickness
  //tft.drawLine(ox, oy + 1, x, y + 1, pcolor);
  //tft.drawLine(ox, oy - 1, x, y - 1, pcolor);
  ox = x;
  oy = y;

}



void SetGraph(TFT_eSPI &tft,int XStart, int YStart, int XAbstand, int YAbstand,int XLines, int YLines, uint32_t Fcolor, uint32_t Bcolor, uint32_t ColorLines)
{
img.fillSprite(Bcolor);

for (int i = 0; i < XLines; i++)
drawLineW(tft,XStart, i * YAbstand + YStart, YLines  * XAbstand + XStart, Fcolor, ColorLines);

for (int i = 0; i < YLines; i++)
drawLineH(tft, i * XAbstand + XStart, YStart, XLines * YAbstand + YStart, Fcolor, ColorLines);

 
}


void SetGraphUnion(TFT_eSPI &tft, double x, double y, 
                           byte Xdp, byte Ydp,
                           double gx, double gy, double w, double h,
                           double xlo, double xhi, double xinc,
                           double ylo, double yhi, double yinc,
                           uint16_t Fcolor, uint16_t Bcolor, uint16_t Gcolor)
 {

  double ydiv, xdiv;
  double i;
  double temp;
  int rot, newrot;

 
    // initialize old x and old y in order to draw the first point of the graph
    // but save the transformed value
    // note my transform funcition is the same as the map function, except the map uses long and we need doubles
    //ox = (x - xlo) * ( w) / (xhi - xlo) + gx;
    //oy = (y - ylo) * (gy - h - gy) / (yhi - ylo) + gy;

    tft.setTextDatum(MR_DATUM);

    // draw y scale
    for ( i = ylo; i <= yhi; i += yinc) {
      // compute the transform
      temp =  (i - ylo) * (gy - h - gy) / (yhi - ylo) + gy;

      if (i == 0) 
        tft.drawLine(gx, temp, gx + w, temp, Gcolor);
     
      // draw the axis labels
      tft.setTextColor(Fcolor, Bcolor);
      // precision is default Arduino--this could really use some format control
      tft.drawFloat(i, Ydp, gx - 4, temp, 1);
    }

    // draw x scale
    for (i = xlo; i <= xhi; i += xinc) {

      // compute the transform
      temp =  (i - xlo) * ( w) / (xhi - xlo) + gx;
      if (i == 0) 
       tft.drawLine(temp, gy, temp, gy - h, Gcolor);
     
      // draw the axis labels
      tft.setTextColor(Fcolor, Bcolor);
      tft.setTextDatum(TC_DATUM);
      // precision is default Arduino--this could really use some format control
      tft.drawFloat(i, Xdp, temp, gy + 7, 1);
    }
}